SET SERVEROUTPUT ON

-- 1) Variable bind: se guarda como texto (DD/MM/YYYY)
VARIABLE b_fecha_proceso VARCHAR2(10);
BEGIN
  :b_fecha_proceso := TO_CHAR(SYSDATE,'DD/MM/YYYY');
END;
/
PRINT b_fecha_proceso

-- 2) Vaciar tabla antes del proceso
TRUNCATE TABLE usuario_clave;

-- 3) Bloque PL/SQL
DECLARE
  -- Contadores para controlar COMMIT final
  v_total_empleados   NUMBER := 0;
  v_procesados_ok     NUMBER := 0;

  -- Fecha de proceso como DATE real (convertida desde la bind)
  v_fecha_proceso     DATE;

  -- Variables %TYPE (mínimo 3)
  v_numrun_emp        empleado.numrun_emp%TYPE;
  v_dvrun_emp         empleado.dvrun_emp%TYPE;
  v_appaterno_emp     empleado.appaterno_emp%TYPE;
  v_apmaterno_emp     empleado.apmaterno_emp%TYPE;
  v_pnombre_emp       empleado.pnombre_emp%TYPE;
  v_snombre_emp       empleado.snombre_emp%TYPE;
  v_fecha_nac         empleado.fecha_nac%TYPE;
  v_fecha_contrato    empleado.fecha_contrato%TYPE;
  v_sueldo_base       empleado.sueldo_base%TYPE;
  v_estado_civil      empleado.id_estado_civil%TYPE;

  -- Variables para construir usuario/clave
  v_nombre_empleado   VARCHAR2(60);
  v_nombre_usuario    VARCHAR2(20);
  v_clave_usuario     VARCHAR2(40);

  v_letra_est_civil   CHAR(1);
  v_anios_trab        NUMBER;
  v_mes_anno          VARCHAR2(6);

  v_tercer_dig_run     CHAR(1);
  v_anno_nac_mas2      NUMBER;
  v_ult3_sueldo_m1     NUMBER;
  v_ult3_sueldo_m1_txt VARCHAR2(3);

BEGIN
  -- Convertir la bind (texto) a DATE real para trabajar sin errores
  v_fecha_proceso := TO_DATE(:b_fecha_proceso, 'DD/MM/YYYY');

  -- Contar empleados que realmente existen en el rango 100..320
  SELECT COUNT(*)
    INTO v_total_empleados
    FROM empleado
   WHERE id_emp BETWEEN 100 AND 320;

  -- Mes y año usando la fecha de proceso real
  v_mes_anno := TO_CHAR(v_fecha_proceso, 'MMYYYY');

  -- Iteración pedida: id_emp desde 100 hasta 320
  FOR v_id_emp IN 100..320 LOOP
    BEGIN
      -- Traer datos del empleado (solo datos)
      SELECT numrun_emp, dvrun_emp,
             appaterno_emp, apmaterno_emp, pnombre_emp, snombre_emp,
             fecha_nac, fecha_contrato, sueldo_base, id_estado_civil
        INTO v_numrun_emp, v_dvrun_emp,
             v_appaterno_emp, v_apmaterno_emp, v_pnombre_emp, v_snombre_emp,
             v_fecha_nac, v_fecha_contrato, v_sueldo_base, v_estado_civil
        FROM empleado
       WHERE id_emp = v_id_emp;

      -- Nombre completo (maneja segundo nombre nulo)
      v_nombre_empleado :=
        TRIM(v_pnombre_emp || ' ' || NVL(v_snombre_emp, '') || ' ' || v_appaterno_emp || ' ' || v_apmaterno_emp);

      -- Letra estado civil (IDs: 10,20,30,40,50,60)
      v_letra_est_civil :=
        CASE v_estado_civil
          WHEN 10 THEN 'c' -- CASADO
          WHEN 20 THEN 'd' -- DIVORCIADO
          WHEN 30 THEN 's' -- SOLTERO
          WHEN 40 THEN 'v' -- VIUDO
          WHEN 50 THEN 's' -- SEPARADO
          WHEN 60 THEN 'a' -- ACUERDO DE UNION CIVIL
          ELSE 'x'
        END;

      -- Años trabajados (entero) usando la fecha de proceso real
      v_anios_trab := TRUNC(MONTHS_BETWEEN(v_fecha_proceso, v_fecha_contrato) / 12);

      -- Construcción NOMBRE_USUARIO (en PL/SQL)
      v_nombre_usuario :=
          v_letra_est_civil
        || LOWER(SUBSTR(v_pnombre_emp, 1, 3))
        || LENGTH(v_pnombre_emp)
        || '*'
        || MOD(TRUNC(v_sueldo_base), 10)
        || v_dvrun_emp
        || v_anios_trab
        || CASE WHEN v_anios_trab < 10 THEN 'X' ELSE '' END;

      -- Partes de la CLAVE
      -- 3er dígito del RUN (blindado por si el RUN tiene menos de 3 dígitos)
      v_tercer_dig_run := SUBSTR(LPAD(TO_CHAR(v_numrun_emp), 3, '0'), 3, 1);

      -- Año nacimiento + 2
      v_anno_nac_mas2 := TO_NUMBER(TO_CHAR(v_fecha_nac, 'YYYY')) + 2;

      -- Últimos 3 dígitos del sueldo, menos 1 (sin convertir a texto)
      v_ult3_sueldo_m1 := MOD(TRUNC(v_sueldo_base), 1000);
      v_ult3_sueldo_m1 := MOD(v_ult3_sueldo_m1 - 1 + 1000, 1000);
      v_ult3_sueldo_m1_txt := LPAD(v_ult3_sueldo_m1, 3, '0');

      -- Dos letras del apellido paterno según estado civil (en minúscula)
      DECLARE
        v_apellido_lower VARCHAR2(30);
        v_dos_letras     VARCHAR2(2);
      BEGIN
        v_apellido_lower := LOWER(v_appaterno_emp);

        v_dos_letras :=
          CASE v_estado_civil
            WHEN 10 THEN SUBSTR(v_apellido_lower, 1, 2)                                       -- casado
            WHEN 60 THEN SUBSTR(v_apellido_lower, 1, 2)                                       -- acuerdo unión civil
            WHEN 20 THEN SUBSTR(v_apellido_lower, 1, 1) || SUBSTR(v_apellido_lower, -1, 1)    -- divorciado
            WHEN 30 THEN SUBSTR(v_apellido_lower, 1, 1) || SUBSTR(v_apellido_lower, -1, 1)    -- soltero
            WHEN 40 THEN SUBSTR(v_apellido_lower, -3, 1) || SUBSTR(v_apellido_lower, -2, 1)   -- viudo
            WHEN 50 THEN SUBSTR(v_apellido_lower, -2, 2)                                      -- separado
            ELSE SUBSTR(v_apellido_lower, 1, 2)
          END;

        -- Construcción final CLAVE_USUARIO
        v_clave_usuario :=
            v_tercer_dig_run
          || v_anno_nac_mas2
          || v_ult3_sueldo_m1_txt
          || v_dos_letras
          || v_id_emp
          || v_mes_anno;
      END;

      -- Insertar resultado
      INSERT INTO usuario_clave (id_emp, numrun_emp, dvrun_emp, nombre_empleado, nombre_usuario, clave_usuario)
      VALUES (v_id_emp, v_numrun_emp, v_dvrun_emp, v_nombre_empleado, v_nombre_usuario, v_clave_usuario);

      v_procesados_ok := v_procesados_ok + 1;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL; -- si no existe ese id_emp, lo salta
    END;
  END LOOP;

  -- Confirmación final SOLO si todo calza
  IF v_procesados_ok = v_total_empleados THEN
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('OK: Procesados '||v_procesados_ok||' de '||v_total_empleados||'. COMMIT realizado.');
  ELSE
    ROLLBACK;
    RAISE_APPLICATION_ERROR(-20001,
      'No se procesaron todos los empleados. OK='||v_procesados_ok||' TOTAL='||v_total_empleados);
  END IF;
END;
/

---Validación---
SELECT *
FROM usuario_clave
ORDER BY id_emp;

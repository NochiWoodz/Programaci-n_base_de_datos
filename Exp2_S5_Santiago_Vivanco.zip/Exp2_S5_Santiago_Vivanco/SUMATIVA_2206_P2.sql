/* ---
   Autor           : Santiago Vivanco
   Asignatura      : PRY2206 – Programación de Base de Datos
   Actividad       : Actividad Sumativa Semana 5
--- */

SET SERVEROUTPUT ON;

DECLARE
  -- Año paramétrico: año anterior al actual
  v_anno NUMBER := EXTRACT(YEAR FROM SYSDATE) - 1;

  -- (k) VARRAY: tipos a considerar
  TYPE t_varray_tipos IS VARRAY(2) OF VARCHAR2(50);
  v_tipos t_varray_tipos := t_varray_tipos(
    'Avance en Efectivo',
    'Súper Avance en Efectivo'
    -- si falla la ú:
    -- 'S' || CHR(250) || 'per Avance en Efectivo'
  );

  -- (m) contadores
  v_total_reg  NUMBER := 0;
  v_procesados NUMBER := 0;

  -- (h) variables de cálculo
  v_porc_aporte NUMBER := 0;
  v_aporte      NUMBER := 0;

  -- (j) excepciones
  e_sin_privilegios EXCEPTION;
  PRAGMA EXCEPTION_INIT(e_sin_privilegios, -1031);

  e_iteraciones_no_cuadran EXCEPTION;

  ---------------------------------------------------------------------------
  -- Cursor 1 (explícito): DETALLE (orden pedido f)
  ---------------------------------------------------------------------------
  CURSOR cur_detalle IS
    SELECT
      c.numrun,
      c.dvrun,
      tc.nro_tarjeta,
      t.nro_transaccion,
      t.fecha_transaccion,
      tt.nombre_tptran_tarjeta AS tipo_transaccion,
      t.monto_transaccion,
      t.monto_total_transaccion
    FROM transaccion_tarjeta_cliente t
    JOIN tarjeta_cliente tc ON tc.nro_tarjeta = t.nro_tarjeta
    JOIN cliente c          ON c.numrun = tc.numrun
    JOIN tipo_transaccion_tarjeta tt
      ON tt.cod_tptran_tarjeta = t.cod_tptran_tarjeta
    WHERE EXTRACT(YEAR FROM t.fecha_transaccion) = v_anno
      AND tt.nombre_tptran_tarjeta IN ('Avance en Efectivo', 'Súper Avance en Efectivo')
    ORDER BY t.fecha_transaccion ASC, c.numrun ASC;

  ---------------------------------------------------------------------------
  -- Cursor 2: lista mes/tipo (orden pedido e)
  ---------------------------------------------------------------------------
    CURSOR cur_mes_tipo IS
      SELECT DISTINCT
        TO_CHAR(t.fecha_transaccion, 'MMYYYY') AS mes_anno,
        tt.nombre_tptran_tarjeta AS tipo_transaccion
      FROM transaccion_tarjeta_cliente t
      JOIN tipo_transaccion_tarjeta tt
        ON tt.cod_tptran_tarjeta = t.cod_tptran_tarjeta
      WHERE EXTRACT(YEAR FROM t.fecha_transaccion) = v_anno
        AND tt.nombre_tptran_tarjeta IN ('Avance en Efectivo', 'Súper Avance en Efectivo')
      ORDER BY SUBSTR(TO_CHAR(t.fecha_transaccion,'MMYYYY'),3,4) ASC,
               SUBSTR(TO_CHAR(t.fecha_transaccion,'MMYYYY'),1,2) ASC,
               tt.nombre_tptran_tarjeta ASC;


  -- Cursor con parámetro (b)
  CURSOR cur_trans_mes_tipo(p_mes VARCHAR2, p_tipo VARCHAR2) IS
    SELECT t.monto_total_transaccion
    FROM transaccion_tarjeta_cliente t
    JOIN tipo_transaccion_tarjeta tt
      ON tt.cod_tptran_tarjeta = t.cod_tptran_tarjeta
    WHERE EXTRACT(YEAR FROM t.fecha_transaccion) = v_anno
      AND TO_CHAR(t.fecha_transaccion,'MMYYYY') = p_mes
      AND tt.nombre_tptran_tarjeta = p_tipo;

  ---------------------------------------------------------------------------
  -- Función (ahora al final del DECLARE) para validar VARRAY (k)
  ---------------------------------------------------------------------------
  FUNCTION tipo_en_varray(p_tipo VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    FOR i IN 1 .. v_tipos.COUNT LOOP
      IF v_tipos(i) = p_tipo THEN
        RETURN TRUE;
      END IF;
    END LOOP;
    RETURN FALSE;
  END tipo_en_varray;

BEGIN
  -- (g) TRUNCATE en ejecución
  EXECUTE IMMEDIATE 'TRUNCATE TABLE DETALLE_APORTE_SBIF';
  EXECUTE IMMEDIATE 'TRUNCATE TABLE RESUMEN_APORTE_SBIF';

  -- Total a procesar (m)
  SELECT COUNT(*)
    INTO v_total_reg
    FROM transaccion_tarjeta_cliente t
    JOIN tipo_transaccion_tarjeta tt
      ON tt.cod_tptran_tarjeta = t.cod_tptran_tarjeta
   WHERE EXTRACT(YEAR FROM t.fecha_transaccion) = v_anno
     AND tt.nombre_tptran_tarjeta IN ('Avance en Efectivo', 'Súper Avance en Efectivo');

  -- DETALLE
  FOR r IN cur_detalle LOOP
    IF NOT tipo_en_varray(r.tipo_transaccion) THEN
      CONTINUE;
    END IF;

    BEGIN
      SELECT porc_aporte_sbif
        INTO v_porc_aporte
        FROM tramo_aporte_sbif
       WHERE r.monto_total_transaccion BETWEEN tramo_inf_av_sav AND tramo_sup_av_sav;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_porc_aporte := 0; -- excepción predefinida (j)
    END;

    v_aporte := ROUND(r.monto_total_transaccion * (v_porc_aporte / 100)); -- (h)

    INSERT INTO detalle_aporte_sbif
      (numrun, dvrun, nro_tarjeta, nro_transaccion, fecha_transaccion,
       tipo_transaccion, monto_transaccion, aporte_sbif)
    VALUES
      (r.numrun, r.dvrun, r.nro_tarjeta, r.nro_transaccion, r.fecha_transaccion,
       r.tipo_transaccion, r.monto_total_transaccion, v_aporte);

    v_procesados := v_procesados + 1;
  END LOOP;

  -- RESUMEN
  FOR m IN cur_mes_tipo LOOP
    DECLARE
      v_sum_monto  NUMBER := 0;
      v_sum_aporte NUMBER := 0;
      v_porc       NUMBER := 0;
      v_ap         NUMBER := 0;
    BEGIN
      FOR t2 IN cur_trans_mes_tipo(m.mes_anno, m.tipo_transaccion) LOOP
        v_sum_monto := v_sum_monto + t2.monto_total_transaccion;

        BEGIN
          SELECT porc_aporte_sbif
            INTO v_porc
            FROM tramo_aporte_sbif
           WHERE t2.monto_total_transaccion BETWEEN tramo_inf_av_sav AND tramo_sup_av_sav;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            v_porc := 0;
        END;

        v_ap := ROUND(t2.monto_total_transaccion * (v_porc / 100));
        v_sum_aporte := v_sum_aporte + v_ap;
      END LOOP;

      INSERT INTO resumen_aporte_sbif
        (mes_anno, tipo_transaccion, monto_total_transacciones, aporte_total_abif)
      VALUES
        (m.mes_anno, m.tipo_transaccion, ROUND(v_sum_monto), ROUND(v_sum_aporte));
    END;
  END LOOP;

  -- COMMIT condicionado (m)
  IF v_procesados <> v_total_reg THEN
    RAISE e_iteraciones_no_cuadran; -- excepción usuario (j)
  END IF;

  COMMIT;
  DBMS_OUTPUT.PUT_LINE('OK. Año='||v_anno||' Total='||v_total_reg||' Procesados='||v_procesados);

EXCEPTION
  WHEN e_sin_privilegios THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('ERROR: sin privilegios (-1031).');

  WHEN e_iteraciones_no_cuadran THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('ERROR: iteraciones no cuadran. Total='||v_total_reg||' Procesados='||v_procesados);

  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('ERROR inesperado: '||SQLERRM);
END;
/


---Verificación---

SELECT COUNT(*) AS detalle FROM DETALLE_APORTE_SBIF;
SELECT COUNT(*) AS resumen FROM RESUMEN_APORTE_SBIF;


SELECT * 
FROM RESUMEN_APORTE_SBIF
ORDER BY SUBSTR(mes_anno,3,4), SUBSTR(mes_anno,1,2), tipo_transaccion;

SELECT *
FROM DETALLE_APORTE_SBIF
ORDER BY fecha_transaccion, numrun;

